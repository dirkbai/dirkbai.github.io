'use strict';

if (mejs.i18n.ca !== undefined) {
	// mejs.i18n.ca["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.cs !== undefined) {
	// mejs.i18n.cs["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.de !== undefined) {
	// mejs.i18n.de["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.es !== undefined) {
	mejs.i18n.es["mejs.quality-chooser"]= "Selector de calidad";
}
if (mejs.i18n.fr !== undefined) {
	// mejs.i18n.fr["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.hr !== undefined) {
	// mejs.i18n.hr["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.hu !== undefined) {
	//mejs.i18n.hu["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.it !== undefined) {
	//mejs.i18n.it["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.ja !== undefined) {
	//mejs.i18n.ja["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.ko !== undefined) {
	//mejs.i18n.ko["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.nl !== undefined) {
	// mejs.i18n.nl["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.pl !== undefined) {
	// mejs.i18n.pl["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.pt !== undefined) {
	//mejs.i18n.pt["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n['pt-BR'] !== undefined) {
	//mejs.i18n['pt-BR']["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.ro !== undefined) {
	//mejs.i18n.ro["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.ru !== undefined) {
	// mejs.i18n.ru["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.sk !== undefined) {
	// mejs.i18n.sk["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.sv !== undefined) {
	// mejs.i18n.sv["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.uk !== undefined) {
	// mejs.i18n.uk["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n.zh !== undefined) {
	//mejs.i18n.zh["mejs.quality-chooser"]= "Quality Chooser";
}
if (mejs.i18n['zh-CN'] !== undefined) {
	//mejs.i18n['zh-CN']["mejs.quality-chooser"]= "Quality Chooser";
}